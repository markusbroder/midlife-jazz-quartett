<?php
    //PLACE YOUR CUSTOM FUNCTIONS HERE

	/*
	UNCOMMENT THIS CODE TO OVERRIDE THE THEME main-min.js FILE
	add_action( 'wp_enqueue_scripts', 'prk_overwrite_scripts', 101 );
	function prk_overwrite_scripts() {
	    wp_deregister_script('fount_main');
	    wp_enqueue_script('fount_main', get_stylesheet_directory_uri() . '/js/main-min.js' );
	    global $prk_fount_options;
	    $prk_fount_options['active_visual_composer']=PRK_FOUNT_COMPOSER;	    
	    wp_localize_script('fount_main', 'theme_options', $prk_fount_options);
	}
	*/
?>
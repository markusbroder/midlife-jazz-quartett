<?php
/*
Plugin Name: Advanced Custom Fields: Sidebar Selector
Plugin URI: https://github.com/elliotcondon/acf-field-type-template
Description: A field which allows you to select sidebars
Version: 1.0.0
Author: Daniel Pataki
Author URI: http://danielpataki.com
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
*/


class acf_field_sidebar_selector_plugin
{
	/*
	*  Construct
	*
	*  @description:
	*  @since: 3.6
	*  @created: 1/04/13
	*/

	function __construct()
	{
		//PIRENKO
		// version 4+
		add_action('init', array($this, 'register_fields'));

	}


	/*
	*  Init
	*
	*  @description:
	*  @since: 3.6
	*  @created: 1/04/13
	*/

	function init()
	{
		if(function_exists('register_field'))
		{
			register_field('acf_field_sidebar_selector', dirname(__File__) . '/sidebar_selector-v3.php');
		}
	}

	/*
	*  register_fields
	*
	*  @description:
	*  @since: 3.6
	*  @created: 1/04/13
	*/

	function register_fields()
	{
		include_once('sidebar_selector-v4.php');
	}

}

new acf_field_sidebar_selector_plugin();

?>

<?php
/**
 * The template for displaying product content within loops.
 *
 * Override this template by copying it to yourtheme/woocommerce/content-product.php
 *
 * @author  WooThemes
 * @package WooCommerce/Templates
 * @version 2.5.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $product, $woocommerce_loop;

// Store loop count we're currently on
if ( empty( $woocommerce_loop['loop'] ) ) {
	$woocommerce_loop['loop'] = 0;
}

// Store column count for displaying the grid
if ( empty( $woocommerce_loop['columns'] ) ) {
	$woocommerce_loop['columns'] = apply_filters( 'loop_shop_columns', 4 );
}

// Ensure visibility
if ( ! $product || ! $product->is_visible() ) {
	return;
}

// Increase loop count
$woocommerce_loop['loop']++;

// Extra post classes
$classes = array();
if ( 0 == ( $woocommerce_loop['loop'] - 1 ) % $woocommerce_loop['columns'] || 1 == $woocommerce_loop['columns'] ) {
	$classes[] = 'first';
}
if ( 0 == $woocommerce_loop['loop'] % $woocommerce_loop['columns'] ) {
	$classes[] = 'last';
}
?>
<li <?php post_class( $classes ); ?>>

	<?php do_action( 'woocommerce_before_shop_loop_item' ); ?>

	<?php

		/**
		 * woocommerce_after_shop_loop_item hook
		 *
		 * @hooked woocommerce_template_loop_add_to_cart - 10
		 */
		do_action( 'woocommerce_after_shop_loop_item' ); 

	?>

	<a href="<?php the_permalink(); ?>">

		<?php //BEGIN FOUNT ?>
		<div class="fount_woo_thumb_wrapper boxed_shadow">
			<?php 
				woocommerce_get_template( 'loop/sale-flash.php' );
			?>
				
				<div class="fount_woo_thumb">
					<a href="<?php the_permalink(); ?>">
						<?php echo woocommerce_get_product_thumbnail();	?>
					</a>
					<a href="<?php echo do_shortcode('[add_to_cart_url id="'.get_the_ID().'"]'); ?>" class="fount_woo_add_button fount_woo_hidden"><span class="left_floated"><?php echo esc_html($product->add_to_cart_text()); ?></span><i class="right_floated fount_fa-shopping-cart"></i></a>
				</div>
		</div>
		<div class="fount_woo_product_info">
			<a href="<?php the_permalink(); ?>"><h3 class="zero_color prk_heavier_600"><?php the_title(); ?></h3></a>
			<div class="fount_woo_hidden fount_woo_cats small_headings_color">
	        	<?php echo $product->get_categories(); ?>
	        </div>
    	</div>
        <?php //END FOUNT ?>
        <?php
			/**
			 * woocommerce_after_shop_loop_item_title hook
			 *
			 * @hooked woocommerce_template_loop_rating - 5
			 * @hooked woocommerce_template_loop_price - 10
			 */
			do_action( 'woocommerce_after_shop_loop_item_title' );
		?>

	</a>

	<?php

		/**
		 * woocommerce_after_shop_loop_item hook
		 *
		 * @hooked woocommerce_template_loop_add_to_cart - 10
		 */
		do_action( 'woocommerce_after_shop_loop_item' );

	?>

</li>
